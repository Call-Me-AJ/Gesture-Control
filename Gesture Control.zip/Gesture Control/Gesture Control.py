import cv2
import os
import numpy as np
from PIL import Image
import math,operator
from functools import reduce
import webbrowser as web
from pyautogui import press,hotkey
import pytube
web.open("https://www.youtube.com/watch?v=iL6uOp8nIhs")
cap=cv2.VideoCapture(0)#the '0' inside the bracket decribes the cam no for default cam on system the no is '0'
i,k,c,l,r=1,0,0,"",""
d={}
o="/m"
permanent_path1="E:/New Mini Project/Gesture Control/Permanent Hand Sing Main/Permanent Right Hand Sign"
permanent_file_name1=[]
permanent_path2="E:/New Mini Project/Gesture Control/Permanent Hand Sing Main/Permanent Left Hand Sign"
permanent_file_name2=[]
permanent_file_path=[]
for a in os.listdir(permanent_path1):
    permanent_file_name1.append(a)
for a in os.listdir(permanent_path2):
    permanent_file_name2.append(a)
while True:
    ret,frame=cap.read()#the 1st argument ('_') returns true or False based on the window(dispaly) properly created or not and 2nd argument ('frame') reads the picture that is seen on the image
    cv2.rectangle(frame, (1, 420), (200, 200), (0, 0, 255), 2)#(frame,(SOP x, SOP y),(EOP x,EOP y),(BLUE,GREEN,RED),thickness) NOTE:-SPO->starting point of
    cv2.rectangle(frame, (450,420),(639, 200), (0, 0, 255), 2)
    while k>75:
        #frame=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)#converting to gray scale
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        lower = np.array([110, 50, 50], dtype = "uint8")# [B,G,R] color code for blue
        upper = np.array([130,255, 255], dtype = "uint8")# [B,G,R] color code for blue
        mask = cv2.inRange(hsv, lower, upper)
        cv2.imwrite("E:/New Mini Project/Gesture Control/Right Hand Pictures/aj"+str(i)+".jpg",mask[200:420,1:204])#gray[SPO height:EPO height,SPO width:EPO width] height:-top(1) to bottom(300) width:-left(1) to right(300)
        cv2.imwrite("E:/New Mini Project/Gesture Control/Left Hand Pictures/aj"+str(i)+".jpg",mask[200:420,450:800])
        #print("picture aj"+str(i)+" taken")
        #i+=1
        img1 = Image.open("E:/New Mini Project/Gesture Control/Right Hand Pictures/aj"+str(i)+".jpg").histogram()
        img=cv2.imread("E:/New Mini Project/Gesture Control/Right Hand Pictures/aj"+str(i)+".jpg")
        cv2.imshow('AJ Right Hand',img)
        for a in permanent_file_name1:
            permanent_image=permanent_path1+o[0]+a
            h2=Image.open(permanent_image).histogram()
            rms = math.sqrt(reduce(operator.add,map(lambda a,b: (a-b)**2, img1, h2))/len(img1))
            d[rms]=a
        #print(d)
        #print("Right ",min(d))
        if min(d)>35:
            r="No Input"
        else:
            no=d.get(min(d))
            n=no.split(".")
            r=n[0][0]
        d={}
        img2 = Image.open("E:/New Mini Project/Gesture Control/Left Hand Pictures/aj"+str(i)+".jpg").histogram()
        img=cv2.imread("E:/New Mini Project/Gesture Control/Left Hand Pictures/aj"+str(i)+".jpg")
        cv2.imshow('AJ Left Hand',img)
        for a in permanent_file_name2:
            permanent_image=permanent_path2+o[0]+a
            h2=Image.open(permanent_image).histogram()
            rms = math.sqrt(reduce(operator.add,map(lambda a,b: (a-b)**2, img2, h2))/len(img1))
            d[rms]=a
        #print("Left ",min(d))
        if min(d)>25:
            l="No Input"
        else:
            no=d.get(min(d))
            n=no.split(".")
            l=n[0][0]
        #print(r,l)
        #print()
        if r!="No Input" and l=="No Input":
            if r=='a':
                press("right")
                press("right")
            elif r=='b':
                press("left")
                press("left")
            elif r=='c':
                press("m")
            elif r=='d':
                press("k")
            else:
                pass
        elif r=="No Input":
            print("No Command To Proceed")
        elif l!="No Input" and r!="No Input":
            if l=='a' and r=='c':
                vd=0
                while vd<5:
                    hotkey('volumeup')
                    vd+=1
            elif l=='b' and r=='c':
                vd=0
                while vd<5:
                    hotkey('volumedown')
                    vd+=1
            elif l=='a' and r=='a':
                hotkey('shift','n')
            elif l=='a' and r=='b':
                hotkey('alt','left')
            elif l=='b' and r=='b':
                print("download")
                '''video_url ="https://www.youtube.com/watch?v=iL6uOp8nIhs"
                youtube = pytube.YouTube(video_url)
                video = youtube.streams.first()
                video.download('E:/New Mini Project/Downloads')'''
        else:
            pass
        print()
        os.remove("E:/New Mini Project/Gesture Control/Right Hand Pictures/aj"+str(i)+".jpg")
        os.remove("E:/New Mini Project/Gesture Control/Left Hand Pictures/aj"+str(i)+".jpg")
        d={}
        k=-1
    k+=1
    cv2.imshow("Call_Me_AJ",frame)
    if cv2.waitKey(1)==27:
        break
cap.release()
cv2.destroyAllWindows()
